Amit Pandey, 24M0792, CSE
Garima Jain, 24M0772, CSE
Sakshi Pandey, 24M2115, CSE
Sravani Gunnu, 24M2116, CSE